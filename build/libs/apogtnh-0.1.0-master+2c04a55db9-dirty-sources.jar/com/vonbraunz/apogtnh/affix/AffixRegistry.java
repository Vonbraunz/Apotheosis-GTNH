package com.vonbraunz.apogtnh.affix;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.vonbraunz.apogtnh.affix.impl.AffixArmor;
import com.vonbraunz.apogtnh.affix.impl.AffixDamage;
import com.vonbraunz.apogtnh.affix.impl.AffixFeather;
import com.vonbraunz.apogtnh.affix.impl.AffixFire;
import com.vonbraunz.apogtnh.affix.impl.AffixGuardian;
import com.vonbraunz.apogtnh.affix.impl.AffixHeart;
import com.vonbraunz.apogtnh.affix.impl.AffixKnockback;
import com.vonbraunz.apogtnh.affix.impl.AffixLifesteal;
import com.vonbraunz.apogtnh.affix.impl.AffixMovement;
import com.vonbraunz.apogtnh.affix.impl.AffixThorns;

/**
 * HashMap-backed registry for affixes. No IForgeRegistry (doesn't exist in 1.7.10).
 * Registration order is not significant; lookups use the id string.
 */
public class AffixRegistry {

    private static final Map<String, Affix> BY_ID = new HashMap<String, Affix>();

    public static void register(Affix affix) {
        if (affix == null || affix.id == null) return;
        BY_ID.put(affix.id, affix);
    }

    public static Affix get(String id) {
        return BY_ID.get(id);
    }

    public static java.util.Collection<Affix> all() {
        return BY_ID.values();
    }

    /** Filter registered affixes to those legal for the given category. */
    public static List<Affix> forCategory(LootCategory cat) {
        List<Affix> out = new ArrayList<Affix>();
        for (Affix a : BY_ID.values()) {
            if (a.canApplyTo(cat)) out.add(a);
        }
        return out;
    }

    /** Pick N distinct affixes for a category. Returns fewer than N if the pool is small. */
    public static List<Affix> pickDistinct(Random rand, LootCategory cat, int count) {
        List<Affix> pool = new ArrayList<Affix>(forCategory(cat));
        List<Affix> picked = new ArrayList<Affix>();
        while (!pool.isEmpty() && picked.size() < count) {
            picked.add(pool.remove(rand.nextInt(pool.size())));
        }
        return picked;
    }

    /**
     * Register the starter affix set. Add your own here as you build them out.
     * Kept small in the scaffold on purpose — extend once the wiring is proven.
     */
    public static void bootstrap() {
        // Weapon affixes
        register(new AffixDamage()); // +flat hearts
        register(new AffixLifesteal()); // % heal on hit
        register(new AffixKnockback()); // extra knockback
        register(new AffixFire()); // set target on fire

        // Armor affixes
        register(new AffixArmor()); // flat damage reduction
        register(new AffixThorns()); // % reflect on melee hit
        register(new AffixGuardian()); // flat reduction on all armor slots
        register(new AffixHeart()); // +max HP on chest/legs
        register(new AffixMovement()); // +speed on boots
        register(new AffixFeather()); // -fall damage on boots
    }
}
