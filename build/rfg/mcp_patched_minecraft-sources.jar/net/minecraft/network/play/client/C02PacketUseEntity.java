package net.minecraft.network.play.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.world.World;

public class C02PacketUseEntity extends Packet
{
    private int field_149567_a;
    private C02PacketUseEntity.Action field_149566_b;
    private static final String __OBFID = "CL_00001357";

    public C02PacketUseEntity() {}

    @SideOnly(Side.CLIENT)
    public C02PacketUseEntity(Entity p_i45251_1_, C02PacketUseEntity.Action p_i45251_2_)
    {
        this.field_149567_a = p_i45251_1_.getEntityId();
        this.field_149566_b = p_i45251_2_;
    }

    /**
     * Reads the raw packet data from the data stream.
     */
    public void readPacketData(PacketBuffer data) throws IOException
    {
        this.field_149567_a = data.readInt();
        this.field_149566_b = C02PacketUseEntity.Action.field_151421_c[data.readByte() % C02PacketUseEntity.Action.field_151421_c.length];
    }

    /**
     * Writes the raw packet data to the data stream.
     */
    public void writePacketData(PacketBuffer data) throws IOException
    {
        data.writeInt(this.field_149567_a);
        data.writeByte(this.field_149566_b.field_151418_d);
    }

    /**
     * Passes this Packet on to the NetHandler for processing.
     */
    public void processPacket(INetHandlerPlayServer handler)
    {
        handler.processUseEntity(this);
    }

    public Entity func_149564_a(World worldIn)
    {
        return worldIn.getEntityByID(this.field_149567_a);
    }

    public C02PacketUseEntity.Action func_149565_c()
    {
        return this.field_149566_b;
    }

    /**
     * Passes this Packet on to the NetHandler for processing.
     */
    public void processPacket(INetHandler handler)
    {
        this.processPacket((INetHandlerPlayServer)handler);
    }

    public static enum Action
    {
        INTERACT(0),
        ATTACK(1);
        private static final C02PacketUseEntity.Action[] field_151421_c = new C02PacketUseEntity.Action[values().length];
        private final int field_151418_d;

        private static final String __OBFID = "CL_00001358";

        private Action(int actionId)
        {
            this.field_151418_d = actionId;
        }

        static
        {
            C02PacketUseEntity.Action[] var0 = values();
            int var1 = var0.length;

            for (int var2 = 0; var2 < var1; ++var2)
            {
                C02PacketUseEntity.Action var3 = var0[var2];
                field_151421_c[var3.field_151418_d] = var3;
            }
        }
    }
}