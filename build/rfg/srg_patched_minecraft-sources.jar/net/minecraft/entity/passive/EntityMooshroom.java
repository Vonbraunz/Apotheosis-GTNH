package net.minecraft.entity.passive;

import java.util.ArrayList;

import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.IShearable;

public class EntityMooshroom extends EntityCow implements IShearable
{
    private static final String __OBFID = "CL_00001645";

    public EntityMooshroom(World p_i1687_1_)
    {
        super(p_i1687_1_);
        this.func_70105_a(0.9F, 1.3F);
    }

    public boolean func_70085_c(EntityPlayer p_70085_1_)
    {
        ItemStack itemstack = p_70085_1_.field_71071_by.func_70448_g();

        if (itemstack != null && itemstack.func_77973_b() == Items.field_151054_z && this.func_70874_b() >= 0)
        {
            if (itemstack.field_77994_a == 1)
            {
                p_70085_1_.field_71071_by.func_70299_a(p_70085_1_.field_71071_by.field_70461_c, new ItemStack(Items.field_151009_A));
                return true;
            }

            if (p_70085_1_.field_71071_by.func_70441_a(new ItemStack(Items.field_151009_A)) && !p_70085_1_.field_71075_bZ.field_75098_d)
            {
                p_70085_1_.field_71071_by.func_70298_a(p_70085_1_.field_71071_by.field_70461_c, 1);
                return true;
            }
        }

        {
            return super.func_70085_c(p_70085_1_);
        }
    }

    public EntityMooshroom func_90011_a(EntityAgeable p_90011_1_)
    {
        return new EntityMooshroom(this.field_70170_p);
    }

    @Override
    public boolean isShearable(ItemStack item, IBlockAccess world, int x, int y, int z)
    {
        return func_70874_b() >= 0;
    }

    @Override
    public ArrayList<ItemStack> onSheared(ItemStack item, IBlockAccess world, int x, int y, int z, int fortune)
    {
        func_70106_y();
        EntityCow entitycow = new EntityCow(field_70170_p);
        entitycow.func_70012_b(field_70165_t, field_70163_u, field_70161_v, field_70177_z, field_70125_A);
        entitycow.func_70606_j(this.func_110143_aJ());
        entitycow.field_70761_aq = field_70761_aq;
        field_70170_p.func_72838_d(entitycow);
        field_70170_p.func_72869_a("largeexplode", field_70165_t, field_70163_u + (double)(field_70131_O / 2.0F), field_70161_v, 0.0D, 0.0D, 0.0D);

        ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        for (int i = 0; i < 5; i++)
        {
            ret.add(new ItemStack(Blocks.field_150337_Q));
        }
        func_85030_a("mob.sheep.shear", 1.0F, 1.0F);
        return ret;
    }
}