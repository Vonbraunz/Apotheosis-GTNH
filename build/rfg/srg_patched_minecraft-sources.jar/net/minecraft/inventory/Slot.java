package net.minecraft.inventory;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.ResourceLocation;

public class Slot
{
    private final int field_75225_a;
    public final IInventory field_75224_c;
    public int field_75222_d;
    public int field_75223_e;
    public int field_75221_f;
    private static final String __OBFID = "CL_00001762";

    /** Position within background texture file, normally -1 which causes no background to be drawn. */
    protected IIcon backgroundIcon = null;

    /** Background texture file assigned to this slot, if any. Vanilla "/gui/items.png" is used if this is null. */
    @SideOnly(Side.CLIENT)
    protected ResourceLocation texture;

    public Slot(IInventory p_i1824_1_, int p_i1824_2_, int p_i1824_3_, int p_i1824_4_)
    {
        this.field_75224_c = p_i1824_1_;
        this.field_75225_a = p_i1824_2_;
        this.field_75223_e = p_i1824_3_;
        this.field_75221_f = p_i1824_4_;
    }

    public void func_75220_a(ItemStack p_75220_1_, ItemStack p_75220_2_)
    {
        if (p_75220_1_ != null && p_75220_2_ != null)
        {
            if (p_75220_1_.func_77973_b() == p_75220_2_.func_77973_b())
            {
                int i = p_75220_2_.field_77994_a - p_75220_1_.field_77994_a;

                if (i > 0)
                {
                    this.func_75210_a(p_75220_1_, i);
                }
            }
        }
    }

    protected void func_75210_a(ItemStack p_75210_1_, int p_75210_2_) {}

    protected void func_75208_c(ItemStack p_75208_1_) {}

    public void func_82870_a(EntityPlayer p_82870_1_, ItemStack p_82870_2_)
    {
        this.func_75218_e();
    }

    public boolean func_75214_a(ItemStack p_75214_1_)
    {
        return true;
    }

    public ItemStack func_75211_c()
    {
        return this.field_75224_c.func_70301_a(this.field_75225_a);
    }

    public boolean func_75216_d()
    {
        return this.func_75211_c() != null;
    }

    public void func_75215_d(ItemStack p_75215_1_)
    {
        this.field_75224_c.func_70299_a(this.field_75225_a, p_75215_1_);
        this.func_75218_e();
    }

    public void func_75218_e()
    {
        this.field_75224_c.func_70296_d();
    }

    public int func_75219_a()
    {
        return this.field_75224_c.func_70297_j_();
    }

    public ItemStack func_75209_a(int p_75209_1_)
    {
        return this.field_75224_c.func_70298_a(this.field_75225_a, p_75209_1_);
    }

    public boolean func_75217_a(IInventory p_75217_1_, int p_75217_2_)
    {
        return p_75217_1_ == this.field_75224_c && p_75217_2_ == this.field_75225_a;
    }

    public boolean func_82869_a(EntityPlayer p_82869_1_)
    {
        return true;
    }

    @SideOnly(Side.CLIENT)
    public IIcon func_75212_b()
    {
        return backgroundIcon;
    }

    @SideOnly(Side.CLIENT)
    public boolean func_111238_b()
    {
        return true;
    }

    /*========================================= FORGE START =====================================*/
    /**
     * Gets the path of the texture file to use for the background image of this slot when drawing the GUI.
     * @return String: The texture file that will be used in GuiContainer.drawSlotInventory for the slot background.
     */
    @SideOnly(Side.CLIENT)
    public ResourceLocation getBackgroundIconTexture()
    {
        return (texture == null ? TextureMap.field_110576_c : texture);
    }

    /**
     * Sets which icon index to use as the background image of the slot when it's empty.
     * @param icon The icon to use, null for none
     */
    public void setBackgroundIcon(IIcon icon)
    {
        backgroundIcon = icon;
    }

    /**
     * Sets the texture file to use for the background image of the slot when it's empty.
     * @param textureFilename String: Path of texture file to use, or null to use "/gui/items.png"
     */
    @SideOnly(Side.CLIENT)
    public void setBackgroundIconTexture(ResourceLocation texture)
    {
        this.texture = texture;
    }

    /**
     * Retrieves the index in the inventory for this slot, this value should typically not
     * be used, but can be useful for some occasions.
     *
     * @return Index in associated inventory for this slot.
     */
    public int getSlotIndex()
    {
        return field_75225_a;
    }
    /*========================================= FORGE END =====================================*/
}