package net.minecraft.item;

import java.util.ArrayList;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.stats.StatList;
import net.minecraft.world.World;
import net.minecraftforge.common.IShearable;

public class ItemShears extends Item
{
    private static final String __OBFID = "CL_00000062";

    public ItemShears()
    {
        this.func_77625_d(1);
        this.func_77656_e(238);
        this.func_77637_a(CreativeTabs.field_78040_i);
    }

    public boolean func_150894_a(ItemStack p_150894_1_, World p_150894_2_, Block p_150894_3_, int p_150894_4_, int p_150894_5_, int p_150894_6_, EntityLivingBase p_150894_7_)
    {
        if (p_150894_3_.func_149688_o() != Material.field_151584_j && p_150894_3_ != Blocks.field_150321_G && p_150894_3_ != Blocks.field_150329_H && p_150894_3_ != Blocks.field_150395_bd && p_150894_3_ != Blocks.field_150473_bD && !(p_150894_3_ instanceof IShearable))
        {
            return super.func_150894_a(p_150894_1_, p_150894_2_, p_150894_3_, p_150894_4_, p_150894_5_, p_150894_6_, p_150894_7_);
        }
        else
        {
            return true;
        }
    }

    public boolean func_150897_b(Block p_150897_1_)
    {
        return p_150897_1_ == Blocks.field_150321_G || p_150897_1_ == Blocks.field_150488_af || p_150897_1_ == Blocks.field_150473_bD;
    }

    public float func_150893_a(ItemStack p_150893_1_, Block p_150893_2_)
    {
        return p_150893_2_ != Blocks.field_150321_G && p_150893_2_.func_149688_o() != Material.field_151584_j ? (p_150893_2_ == Blocks.field_150325_L ? 5.0F : super.func_150893_a(p_150893_1_, p_150893_2_)) : 15.0F;
    }

    @Override
    public boolean func_111207_a(ItemStack itemstack, EntityPlayer player, EntityLivingBase entity)
    {
        if (entity.field_70170_p.field_72995_K)
        {
            return false;
        }
        if (entity instanceof IShearable)
        {
            IShearable target = (IShearable)entity;
            if (target.isShearable(itemstack, entity.field_70170_p, (int)entity.field_70165_t, (int)entity.field_70163_u, (int)entity.field_70161_v))
            {
                ArrayList<ItemStack> drops = target.onSheared(itemstack, entity.field_70170_p, (int)entity.field_70165_t, (int)entity.field_70163_u, (int)entity.field_70161_v,
                        EnchantmentHelper.func_77506_a(Enchantment.field_77346_s.field_77352_x, itemstack));

                Random rand = new Random();
                for(ItemStack stack : drops)
                {
                    EntityItem ent = entity.func_70099_a(stack, 1.0F);
                    ent.field_70181_x += rand.nextFloat() * 0.05F;
                    ent.field_70159_w += (rand.nextFloat() - rand.nextFloat()) * 0.1F;
                    ent.field_70179_y += (rand.nextFloat() - rand.nextFloat()) * 0.1F;
                }
                itemstack.func_77972_a(1, entity);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean onBlockStartBreak(ItemStack itemstack, int x, int y, int z, EntityPlayer player)
    {
        if (player.field_70170_p.field_72995_K)
        {
            return false;
        }
        Block block = player.field_70170_p.func_147439_a(x, y, z);
        if (block instanceof IShearable)
        {
            IShearable target = (IShearable)block;
            if (target.isShearable(itemstack, player.field_70170_p, x, y, z))
            {
                ArrayList<ItemStack> drops = target.onSheared(itemstack, player.field_70170_p, x, y, z,
                        EnchantmentHelper.func_77506_a(Enchantment.field_77346_s.field_77352_x, itemstack));
                Random rand = new Random();

                for(ItemStack stack : drops)
                {
                    float f = 0.7F;
                    double d  = (double)(rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    double d1 = (double)(rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    double d2 = (double)(rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    EntityItem entityitem = new EntityItem(player.field_70170_p, (double)x + d, (double)y + d1, (double)z + d2, stack);
                    entityitem.field_145804_b = 10;
                    player.field_70170_p.func_72838_d(entityitem);
                }

                itemstack.func_77972_a(1, player);
                player.func_71064_a(StatList.field_75934_C[Block.func_149682_b(block)], 1);
            }
        }
        return false;
    }
}